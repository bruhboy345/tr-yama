-- BECERILER --

st_menu_mastermind = "Deha",
st_menu_enforcer = "İnfazci",
st_menu_technician = "Teknisyen",
st_menu_ghost = "Hayalet",
st_menu_hoxton_pack = "Kaçak",
skill_tree_reset_skills_button = "$BTN_RESET_SKILLS; Bu kökü sifirla",
skill_tree_reset_all_skills_button = "$BTN_RESET_ALL_SKILLS; Tüm kökleri sifirla",
menu_st_switch_skillset = "$BTN_SKILLSET; Beceri setini deĞistir",
menu_skillpoints = "Kalan Beceri Puani",
menu_st_points_unlock = "AÇMAK İÇİN GEREKLİ PUAN",
menu_st_skill_switch_title = "Beceri / Donanim DeĞistir",
menu_st_points_unspent_skill_switch = "$points; puan mevcut",
menu_st_skill_switch_title_status = "Durum:",
menu_st_skill_switch_title_name = "Sira:",
menu_st_active_skill_switch = "AKTİF",
menu_st_make_active_skill_switch = "AKTİFLEŞTİR",

