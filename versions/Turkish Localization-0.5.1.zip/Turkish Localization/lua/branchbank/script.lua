-- HEDEFLER :D

hud_v_branchbank_mission2 = "Tüm parayi çantaya doldurun",
hud_v_branchbank_mission2_hl = "Parayi alin",
hud_v_branchbank_mission4_hl = "Kaçis Mevcut",
hud_v_branchbank_mission9_hl = "Termit Dirili Birak",
hud_v_branchbank_mission4 = "Kaçış aracına bin",
hud_v_branchbank_mission8_hl = "Termit dirili al",
hud_v_branchbank_mission1 = "Termit dirili kasaya erismek için kullan",
hud_v_branchbank_mission1_hl = "Kasayi del",
hud_v_branchbank_mission3 = "Parayi korumak için kamyonetin at",
hud_v_branchbank_mission3_hl = "Parayi koru",
hud_v_branchbank_mission5 = "Altini korumak için kamyonetin içine at",
hud_v_branchbank_mission5_hl = "Altini koru",
hud_v_branchbank_mission6 = "Banka kutularda arama yapin",
hud_v_branchbank_mission6_hl = "Banka kutularda arama yapin",
hud_v_branchbank_mission7 = "Kasadaki tüm altinlari çalin",
hud_v_branchbank_mission7_hl = "Altini çal",
hud_v_branchbank_mission8 = "Açik otoparktan termit dirili al",
hud_v_branchbank_mission9 = "Termit dirili kasaya doĞru tasi",



