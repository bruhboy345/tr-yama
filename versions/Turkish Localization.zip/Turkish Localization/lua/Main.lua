Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_Main", function(loc)

	local texts = {}
	
	local file_names = {
		"mods/Turkish Localization/lua/menu/payday2.lua",
		"mods/Turkish Localization/lua/menu/menu.lua",
		"mods/Turkish Localization/lua/menu/hud.lua"
	}

	for _,filename in pairs(file_names or {})do
		local da = io.open(filename,"r")
		if da then
			local txt = da:read("*a")
				io.close(da)
			if txt and type(txt) == "string" then
				local data = assert(loadstring("local text = {\n"..txt.."\n}return text"))()
				if data and type(data) == "table" then
					for i,v in pairs(data)do
						if v ~= "" then
							texts[i] = v
						end
					end
				end
			end
		end
	end
	loc:add_localized_strings(texts)
end
)

function LocalizationManager.text( self, str, macros )

	if self._custom_localizations[str] then
		local return_str = self._custom_localizations[str]
		if macros and type(macros) == "table" then
			for k, v in pairs( macros ) do
				return_str = return_str:gsub( "$" .. k .. ";", "$" .. k .. ";")
			end
		end
		self._macro_context = macros
		return_str = self:_localizer_post_process( return_str )
		self._macro_context = nil
		return return_str
	end
	return self.orig.text(self, str, macros)

end