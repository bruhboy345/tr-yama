# PAYDAY 2 TÜRKÇE YAMA [TURKISH LOCALIZATION]

Merhaba!
Ben bruhboy345 ve sizlerle birlikte bu modla birlikteyim. Biliyorsunuz ki bundan 4 sene önce çıkan Bir tane Türkçe Yama modu vardı ancak 4 senedir güncelleme almıyor ve üzücü bir şekilde betada kaldı :( Ben de düşündüm kendim yapabilir miyim ve evet artık bu modla karşı karşıyasınız keyfini çıkarın!

## CREDITS

[CENSOR_1337](https://modworkshop.net/user/12851) - String list - String listesi

## EXTRA CREDITS

[Triplxt](https://steamcommunity.com/profiles/76561198226673204) - Old Turkish Localization Mod Coder - Eski Türkçe Yama mod kodlayıcısı

[OLD TURKISH LOCALIZATION LINK](https://modworkshop.net/mod/13894)

## EKİP

GGaben - Çevirmen

bruhboy345 - Yazılımcı & Çevirmen

### Çalışmayan ekip :)

ASmileOk? - Çevirmen

Kadri1200 - Çevirmen

Slyy - Çevirmen

### BİLGİLENDİRME

**Ne yaparsan yap kredi vermeyi unutma**


### NOT 

**ESKİ YAMA KODLARININ KULLANILMASI İÇİN İZİN ALINMIŞTIR.**

[Discord Sunucusu](https://discord.gg/5STMXspFjq)